# KriptoPanel

Türkçe, koyu temalı Expo / React Native kripto takip prototipi.

## Özellikler
- Binance genel API üzerinden BTC, ETH, BNB, SOL, XRP ve DOGE fiyatları (30 saniyede bir yenileme)
- Portföy ekleme ve tahmini kâr/zarar hesabı
- Takip listesi
- 24 saatlik en yüksek/en düşük fiyat aralığı ve basit momentum göstergesi
- Uygulama açıkken çalışan hedef fiyat uyarıları
- Binance bağlantısı için güvenlik bilgilendirme ekranı

## Çalıştırma
1. Bilgisayarına Node.js LTS kur: https://nodejs.org/
2. Bu klasörde terminal aç.
3. `npm install` çalıştır.
4. `npx expo start` çalıştır.
5. Android telefonuna Expo Go kur ve terminaldeki QR kodu okut. Bilgisayar ve telefon aynı Wi-Fi ağında olmalı.

Web önizlemesi için `npm run web` (gerekirse `npx expo install react-native-web`) kullanabilirsin.

## Önemli sınırlamalar
- Bu bir başlangıç prototipidir; portföy, takip listesi ve uyarılar cihazda kalıcı olarak saklanmıyor.
- Fiyatlar Binance'in herkese açık API'sinden USDT pariteleri olarak gelir; erişim, ülke/ağ koşullarına göre değişebilir.
- Grafik ekranı gerçek mum grafiği değil, 24 saatlik aralık göstergesidir.
- Uyarılar yalnızca uygulama açıkken çalışır; arka plan/push bildirimleri eklenmemiştir.
- Binance hesabı bağlantısı henüz gerçek API entegrasyonu değildir. Gerçek entegrasyon için backend gerekir. API secret/anahtarlarını asla mobil uygulama içine gömme. İlk aşamada salt-okunur API anahtarı kullan; para çekme iznini kapalı tut.
- Momentum göstergesi yatırım tavsiyesi değildir. Finansal kararlar için tek başına kullanma.
