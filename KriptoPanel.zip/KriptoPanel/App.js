import React, { useEffect, useMemo, useState } from 'react';
import {
  SafeAreaView, View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, ActivityIndicator, RefreshControl, Alert, StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const API = 'https://api.binance.com/api/v3';
const START_COINS = [
  { symbol: 'BTCUSDT', ticker: 'BTC', name: 'Bitcoin', color: '#F7931A' },
  { symbol: 'ETHUSDT', ticker: 'ETH', name: 'Ethereum', color: '#8795F7' },
  { symbol: 'BNBUSDT', ticker: 'BNB', name: 'BNB', color: '#F3BA2F' },
  { symbol: 'SOLUSDT', ticker: 'SOL', name: 'Solana', color: '#9C7BFA' },
  { symbol: 'XRPUSDT', ticker: 'XRP', name: 'XRP', color: '#8C9AA8' },
  { symbol: 'DOGEUSDT', ticker: 'DOGE', name: 'Dogecoin', color: '#C2A633' },
];

const money = (n) => Number(n || 0).toLocaleString('tr-TR', {
  minimumFractionDigits: 2, maximumFractionDigits: 2
});
const price = (n) => Number(n || 0).toLocaleString('tr-TR', {
  minimumFractionDigits: 2, maximumFractionDigits: Number(n) < 1 ? 6 : 2
});

export default function App() {
  const [tab, setTab] = useState('Piyasa');
  const [prices, setPrices] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [watch, setWatch] = useState(['BTCUSDT', 'ETHUSDT', 'SOLUSDT']);
  const [holdings, setHoldings] = useState([
    { symbol: 'BTCUSDT', ticker: 'BTC', qty: '0.01', avg: '60000' },
    { symbol: 'ETHUSDT', ticker: 'ETH', qty: '0.2', avg: '2500' },
  ]);
  const [coin, setCoin] = useState('BTCUSDT');
  const [qty, setQty] = useState('0.01');
  const [avg, setAvg] = useState('60000');
  const [alertSymbol, setAlertSymbol] = useState('BTCUSDT');
  const [alertTarget, setAlertTarget] = useState('');
  const [alerts, setAlerts] = useState([]);
  const [binanceStatus, setBinanceStatus] = useState('Bağlı değil');

  const loadPrices = async () => {
    try {
      const response = await fetch(`${API}/ticker/24hr`);
      if (!response.ok) throw new Error('Piyasa verisi alınamadı');
      const data = await response.json();
      const wanted = {};
      data.filter(x => START_COINS.some(c => c.symbol === x.symbol)).forEach(x => {
        wanted[x.symbol] = {
          last: Number(x.lastPrice),
          change: Number(x.priceChangePercent),
          high: Number(x.highPrice),
          low: Number(x.lowPrice),
          volume: Number(x.quoteVolume)
        };
      });
      setPrices(wanted);
    } catch (e) {
      Alert.alert('Bağlantı sorunu', 'Canlı fiyatlar alınamadı. İnternet bağlantını kontrol edip yeniden dene.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadPrices();
    const timer = setInterval(loadPrices, 30000);
    return () => clearInterval(timer);
  }, []);

  const coinInfo = (symbol) => START_COINS.find(c => c.symbol === symbol) || {
    symbol, ticker: symbol.replace('USDT', ''), name: symbol, color: '#8B9BB4'
  };

  const totalValue = useMemo(() => holdings.reduce((sum, h) => {
    return sum + (Number(h.qty) || 0) * (prices[h.symbol]?.last || 0);
  }, 0), [holdings, prices]);

  const totalCost = useMemo(() => holdings.reduce((sum, h) =>
    sum + (Number(h.qty) || 0) * (Number(h.avg) || 0), 0), [holdings]);

  const pnl = totalValue - totalCost;
  const pnlPct = totalCost ? (pnl / totalCost) * 100 : 0;

  const addHolding = () => {
    const q = Number(qty), a = Number(avg);
    if (!q || q <= 0 || !a || a <= 0) {
      Alert.alert('Bilgileri kontrol et', 'Miktar ve ortalama alış fiyatı sıfırdan büyük olmalı.');
      return;
    }
    setHoldings(prev => {
      const existing = prev.find(h => h.symbol === coin);
      if (existing) {
        const oldQty = Number(existing.qty), oldAvg = Number(existing.avg);
        return prev.map(h => h.symbol !== coin ? h : {
          ...h,
          qty: String(oldQty + q),
          avg: String(((oldQty * oldAvg) + (q * a)) / (oldQty + q))
        });
      }
      return [...prev, { symbol: coin, ticker: coinInfo(coin).ticker, qty: String(q), avg: String(a) }];
    });
    setTab('Portföy');
    Alert.alert('Eklendi', `${coinInfo(coin).ticker} portföyüne eklendi.`);
  };

  const addAlert = () => {
    const target = Number(alertTarget.replace(',', '.'));
    if (!target || target <= 0) {
      Alert.alert('Hedef fiyat gerekli', 'Lütfen geçerli bir USDT fiyatı yaz.');
      return;
    }
    setAlerts(prev => [...prev, { id: Date.now().toString(), symbol: alertSymbol, target, triggered: false }]);
    setAlertTarget('');
    Alert.alert('Uyarı eklendi', 'Uygulama açıkken fiyat hedefini kontrol eder. Arka planda bildirim henüz etkin değil.');
  };

  useEffect(() => {
    setAlerts(prev => prev.map(a => {
      const current = prices[a.symbol]?.last;
      if (!current || a.triggered) return a;
      const crossed = current >= a.target;
      if (crossed) Alert.alert('Fiyat hedefi görüldü', `${coinInfo(a.symbol).ticker} ${price(current)} USDT seviyesine ulaştı.`);
      return crossed ? { ...a, triggered: true } : a;
    }));
  }, [prices]);

  const toggleWatch = (symbol) => setWatch(prev =>
    prev.includes(symbol) ? prev.filter(s => s !== symbol) : [...prev, symbol]
  );

  const testBinance = () => {
    Alert.alert(
      'Binance bağlantısı',
      'Güvenli bağlantı için API anahtarını doğrudan uygulamaya yazma. Gerçek entegrasyonda anahtarlar sunucuda saklanmalı; önce salt-okunur izinli API anahtarı ve güvenli bir backend kurulmalı.',
      [{ text: 'Anladım' }]
    );
  };

  const Header = () => (
    <View style={styles.header}>
      <View style={styles.brandIcon}><Ionicons name="pulse" size={23} color="#08111F" /></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.brand}>Kripto<Text style={{ color: C.green }}>Panel</Text></Text>
        <Text style={styles.subBrand}>PİYASA TAKİP MERKEZİ</Text>
      </View>
      <TouchableOpacity style={styles.iconBtn} onPress={() => { setRefreshing(true); loadPrices(); }}>
        <Ionicons name="refresh" size={20} color={C.text} />
      </TouchableOpacity>
    </View>
  );

  const Stat = ({ label, value, detail, positive }) => (
    <View style={styles.statCard}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
      {detail ? <Text style={[styles.statDetail, { color: positive === undefined ? C.muted : positive ? C.green : C.red }]}>{detail}</Text> : null}
    </View>
  );

  const CoinRow = ({ item, showWatch = false }) => {
    const p = prices[item.symbol];
    const positive = (p?.change || 0) >= 0;
    const watched = watch.includes(item.symbol);
    return (
      <View style={styles.coinRow}>
        <View style={[styles.coinIcon, { backgroundColor: item.color + '22' }]}>
          <Text style={[styles.coinInitial, { color: item.color }]}>{item.ticker.slice(0, 1)}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.coinTicker}>{item.ticker}</Text>
          <Text style={styles.coinName}>{item.name}</Text>
        </View>
        <View style={{ alignItems: 'flex-end', minWidth: 94 }}>
          <Text style={styles.coinPrice}>{p ? `$${price(p.last)}` : '—'}</Text>
          <Text style={[styles.coinChange, { color: positive ? C.green : C.red }]}>
            {p ? `${positive ? '+' : ''}${p.change.toFixed(2)}%` : 'Veri bekleniyor'}
          </Text>
        </View>
        {showWatch && (
          <TouchableOpacity style={styles.starBtn} onPress={() => toggleWatch(item.symbol)}>
            <Ionicons name={watched ? 'star' : 'star-outline'} size={20} color={watched ? C.yellow : C.muted} />
          </TouchableOpacity>
        )}
      </View>
    );
  };

  const Market = () => (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadPrices(); }} tintColor={C.green} />}>
      <View style={styles.greeting}>
        <Text style={styles.eyebrow}>PAZAR, 7/24 AKTİF</Text>
        <Text style={styles.pageTitle}>Piyasaya genel bakış</Text>
        <Text style={styles.muted}>Kripto piyasasını tek ekrandan takip et.</Text>
      </View>
      <View style={styles.heroCard}>
        <View style={styles.heroTop}>
          <View>
            <Text style={styles.heroLabel}>Takip ettiğin varlıklar</Text>
            <Text style={styles.heroValue}>{watch.length} <Text style={styles.heroUnit}>varlık</Text></Text>
          </View>
          <View style={styles.livePill}><View style={styles.liveDot} /><Text style={styles.liveText}>CANLI VERİ</Text></View>
        </View>
        <View style={styles.heroLine} />
        <View style={styles.heroBottom}>
          <View><Text style={styles.statLabel}>BTC / USDT</Text><Text style={styles.heroPrice}>{prices.BTCUSDT ? `$${price(prices.BTCUSDT.last)}` : 'Yükleniyor…'}</Text></View>
          <Text style={[styles.heroChange, { color: (prices.BTCUSDT?.change || 0) >= 0 ? C.green : C.red }]}>
            {prices.BTCUSDT ? `${prices.BTCUSDT.change >= 0 ? '+' : ''}${prices.BTCUSDT.change.toFixed(2)}%` : '—'}
          </Text>
        </View>
      </View>
      <SectionTitle title="Piyasa listesi" right="24 saatlik değişim" />
      <View style={styles.panel}>
        {loading && !Object.keys(prices).length ? <ActivityIndicator color={C.green} style={{ padding: 30 }} /> :
          START_COINS.map((item, i) => <React.Fragment key={item.symbol}><CoinRow item={item} showWatch />{i < START_COINS.length - 1 && <View style={styles.rowDivider} />}</React.Fragment>)}
      </View>
      <Text style={styles.footnote}>Fiyatlar Binance genel piyasa API'sinden alınır, yaklaşık 30 saniyede bir yenilenir.</Text>
    </ScrollView>
  );

  const Portfolio = () => (
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.pageTitle}>Portföyüm</Text>
      <Text style={styles.muted}>Varlıklarını ve tahmini kâr-zararını takip et.</Text>
      <View style={styles.portfolioHero}>
        <Text style={styles.statLabel}>Toplam piyasa değeri</Text>
        <Text style={styles.portfolioValue}>${money(totalValue)}</Text>
        <View style={styles.pnlPill}>
          <Ionicons name={pnl >= 0 ? 'trending-up' : 'trending-down'} size={16} color={pnl >= 0 ? C.green : C.red} />
          <Text style={{ color: pnl >= 0 ? C.green : C.red, fontWeight: '700' }}>{pnl >= 0 ? '+' : ''}${money(pnl)} ({pnlPct.toFixed(2)}%)</Text>
        </View>
        <Text style={styles.portfolioNote}>Girilen ortalama alış fiyatına göre tahmini sonuç</Text>
      </View>
      <View style={styles.statsGrid}>
        <Stat label="Toplam maliyet" value={`$${money(totalCost)}`} />
        <Stat label="Toplam kâr/zarar" value={`${pnl >= 0 ? '+' : ''}$${money(pnl)}`} detail={`${pnlPct.toFixed(2)}%`} positive={pnl >= 0} />
      </View>
      <SectionTitle title="Varlıklarım" right={`${holdings.length} varlık`} />
      <View style={styles.panel}>
        {holdings.length === 0 ? <Text style={styles.emptyText}>Henüz varlık eklemedin.</Text> : holdings.map((h, i) => {
          const c = coinInfo(h.symbol), p = prices[h.symbol]?.last || 0;
          const val = Number(h.qty) * p, cost = Number(h.qty) * Number(h.avg), diff = val - cost;
          return <View key={h.symbol} style={styles.holdingRow}>
            <View style={[styles.coinIcon, { backgroundColor: c.color + '22' }]}><Text style={[styles.coinInitial, { color: c.color }]}>{c.ticker[0]}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.coinTicker}>{c.ticker}</Text>
              <Text style={styles.coinName}>{h.qty} adet · Ort. ${price(Number(h.avg))}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.coinPrice}>${money(val)}</Text>
              <Text style={[styles.coinChange, { color: diff >= 0 ? C.green : C.red }]}>{diff >= 0 ? '+' : ''}${money(diff)}</Text>
            </View>
            <TouchableOpacity onPress={() => Alert.alert('Varlığı kaldır', `${c.ticker} portföyden kaldırılsın mı?`, [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Kaldır', style: 'destructive', onPress: () => setHoldings(prev => prev.filter(x => x.symbol !== h.symbol)) }])} style={styles.deleteBtn}>
              <Ionicons name="close-circle-outline" size={19} color={C.muted} />
            </TouchableOpacity>
          </View>;
        })}
      </View>
      <SectionTitle title="Portföye varlık ekle" />
      <View style={styles.formCard}>
        <Text style={styles.inputLabel}>Kripto para</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
          {START_COINS.map(c => <TouchableOpacity key={c.symbol} onPress={() => setCoin(c.symbol)} style={[styles.chip, coin === c.symbol && styles.chipActive]}><Text style={[styles.chipText, coin === c.symbol && styles.chipTextActive]}>{c.ticker}</Text></TouchableOpacity>)}
        </ScrollView>
        <Text style={styles.inputLabel}>Miktar</Text>
        <TextInput value={qty} onChangeText={setQty} keyboardType="decimal-pad" placeholder="Örn. 0,05" placeholderTextColor={C.muted} style={styles.input} />
        <Text style={styles.inputLabel}>Ortalama alış fiyatı (USDT)</Text>
        <TextInput value={avg} onChangeText={setAvg} keyboardType="decimal-pad" placeholder="Örn. 65000" placeholderTextColor={C.muted} style={styles.input} />
        <TouchableOpacity style={styles.primaryBtn} onPress={addHolding}><Ionicons name="add" size={19} color="#07111F" /><Text style={styles.primaryBtnText}>Portföye ekle</Text></TouchableOpacity>
      </View>
      <Text style={styles.footnote}>Hesaplamalar USDT cinsindendir; komisyon, vergi ve para yatırma/çekme ücretleri dahil değildir.</Text>
    </ScrollView>
  );

  const Watchlist = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>Takip listem</Text>
      <Text style={styles.muted}>Yıldız simgesiyle varlıklarını ekle veya çıkar.</Text>
      <View style={styles.panel}>
        {START_COINS.filter(c => watch.includes(c.symbol)).length === 0 ? <Text style={styles.emptyText}>Takip listesi boş. Piyasa sekmesinden yıldız ekle.</Text> :
          START_COINS.filter(c => watch.includes(c.symbol)).map((item, i, arr) => <React.Fragment key={item.symbol}><CoinRow item={item} showWatch />{i < arr.length - 1 && <View style={styles.rowDivider} />}</React.Fragment>)}
      </View>
      <SectionTitle title="Ekleyebileceklerin" />
      <View style={styles.panel}>
        {START_COINS.filter(c => !watch.includes(c.symbol)).map((item, i, arr) => <React.Fragment key={item.symbol}><CoinRow item={item} showWatch />{i < arr.length - 1 && <View style={styles.rowDivider} />}</React.Fragment>)}
      </View>
    </ScrollView>
  );

  const Charts = () => {
    const selected = coinInfo(coin), p = prices[coin];
    const [unused] = useState(null);
    return (
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.pageTitle}>Grafikler & sinyaller</Text>
        <Text style={styles.muted}>24 saatlik fiyat aralığı ve basit gösterge özeti.</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 16 }}>
          {START_COINS.map(c => <TouchableOpacity key={c.symbol} onPress={() => setCoin(c.symbol)} style={[styles.chip, coin === c.symbol && styles.chipActive]}><Text style={[styles.chipText, coin === c.symbol && styles.chipTextActive]}>{c.ticker}</Text></TouchableOpacity>)}
        </ScrollView>
        <View style={styles.chartCard}>
          <Text style={styles.coinTicker}>{selected.name} / USDT</Text>
          <Text style={styles.chartPrice}>{p ? `$${price(p.last)}` : 'Veri yükleniyor'}</Text>
          <Text style={[styles.coinChange, { color: (p?.change || 0) >= 0 ? C.green : C.red }]}>{p ? `${p.change >= 0 ? '+' : ''}${p.change.toFixed(2)}% son 24 saat` : '—'}</Text>
          <View style={styles.chartPlaceholder}>
            <Ionicons name="analytics-outline" size={40} color={C.green} />
            <Text style={styles.chartPlaceholderTitle}>24 saatlik aralık</Text>
            <Text style={styles.chartRange}>En yüksek  ${p ? price(p.high) : '—'}</Text>
            <View style={styles.rangeLine}><View style={[styles.rangeFill, { width: p && p.high > p.low ? `${Math.max(3, Math.min(100, ((p.last - p.low) / (p.high - p.low)) * 100))}%` : '50%' }]} /></View>
            <Text style={styles.chartRange}>En düşük  ${p ? price(p.low) : '—'}</Text>
          </View>
          <Text style={styles.footnote}>Bu ilk sürümde mum grafiği yerine canlı 24 saatlik aralık gösterilir. Gelişmiş mum grafiklerini sonraki sürümde ekleyebiliriz.</Text>
        </View>
        <SectionTitle title="Basit gösterge" />
        <View style={styles.signalCard}>
          <View style={styles.signalIcon}><Ionicons name="pulse-outline" size={22} color={C.blue} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.coinTicker}>24 saatlik momentum</Text>
            <Text style={styles.coinName}>Sadece günlük değişime dayalı, basit bir gösterge.</Text>
          </View>
          <Text style={{ color: !p ? C.muted : p.change > 2 ? C.green : p.change < -2 ? C.red : C.yellow, fontWeight: '800' }}>
            {!p ? '—' : p.change > 2 ? 'POZİTİF' : p.change < -2 ? 'NEGATİF' : 'NÖTR'}
          </Text>
        </View>
        <Text style={styles.footnote}>Bu yatırım tavsiyesi değildir. Tek bir göstergeden hareketle işlem kararı verme.</Text>
      </ScrollView>
    );
  };

  const AlertsScreen = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>Fiyat uyarıları</Text>
      <Text style={styles.muted}>Hedef fiyat belirle; uygulama açıkken kontrol etsin.</Text>
      <View style={styles.formCard}>
        <Text style={styles.inputLabel}>Varlık</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
          {START_COINS.map(c => <TouchableOpacity key={c.symbol} onPress={() => setAlertSymbol(c.symbol)} style={[styles.chip, alertSymbol === c.symbol && styles.chipActive]}><Text style={[styles.chipText, alertSymbol === c.symbol && styles.chipTextActive]}>{c.ticker}</Text></TouchableOpacity>)}
        </ScrollView>
        <Text style={styles.inputLabel}>Hedef fiyat (USDT)</Text>
        <TextInput value={alertTarget} onChangeText={setAlertTarget} keyboardType="decimal-pad" placeholder="Örn. 70000" placeholderTextColor={C.muted} style={styles.input} />
        <Text style={styles.currentPrice}>Güncel: ${prices[alertSymbol] ? price(prices[alertSymbol].last) : '—'}</Text>
        <TouchableOpacity style={styles.primaryBtn} onPress={addAlert}><Ionicons name="notifications-outline" size={18} color="#07111F" /><Text style={styles.primaryBtnText}>Uyarı oluştur</Text></TouchableOpacity>
      </View>
      <SectionTitle title="Aktif uyarılar" right={`${alerts.filter(a => !a.triggered).length} aktif`} />
      <View style={styles.panel}>
        {alerts.length === 0 ? <Text style={styles.emptyText}>Henüz fiyat uyarısı yok.</Text> : alerts.map(a => {
          const c = coinInfo(a.symbol);
          return <View key={a.id} style={styles.alertRow}>
            <View style={styles.alertIcon}><Ionicons name={a.triggered ? 'checkmark-circle' : 'notifications-outline'} size={20} color={a.triggered ? C.green : C.yellow} /></View>
            <View style={{ flex: 1 }}><Text style={styles.coinTicker}>{c.ticker} · ${price(a.target)}</Text><Text style={styles.coinName}>{a.triggered ? 'Hedef görüldü' : 'Fiyat hedefi'}</Text></View>
            <TouchableOpacity onPress={() => setAlerts(prev => prev.filter(x => x.id !== a.id))}><Ionicons name="trash-outline" size={19} color={C.muted} /></TouchableOpacity>
          </View>;
        })}
      </View>
      <Text style={styles.footnote}>Not: Bu prototipte uyarılar uygulama açıkken çalışır. Arka plan bildirimleri için push bildirimi altyapısı gerekir.</Text>
    </ScrollView>
  );

  const Settings = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>Ayarlar</Text>
      <Text style={styles.muted}>Bağlantılar ve güvenlik.</Text>
      <View style={styles.settingCard}>
        <View style={styles.settingIcon}><Ionicons name="shield-checkmark-outline" size={22} color={C.green} /></View>
        <View style={{ flex: 1 }}><Text style={styles.coinTicker}>Binance hesabı</Text><Text style={styles.coinName}>Durum: {binanceStatus}</Text></View>
        <TouchableOpacity style={styles.outlineBtn} onPress={testBinance}><Text style={styles.outlineBtnText}>Bağla</Text></TouchableOpacity>
      </View>
      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>Güvenlik notları</Text>
        <Text style={styles.infoText}>• API anahtarını sohbetlerde veya uygulama kodunda paylaşma.</Text>
        <Text style={styles.infoText}>• Entegrasyonda para çekme izni kapalı, salt-okunur API anahtarı kullan.</Text>
        <Text style={styles.infoText}>• API anahtarını mobil uygulamaya gömmek güvenli değildir; gerçek bağlantı için sunucu tarafı gerekir.</Text>
      </View>
      <View style={styles.settingCard}>
        <View style={styles.settingIcon}><Ionicons name="cloud-outline" size={22} color={C.blue} /></View>
        <View style={{ flex: 1 }}><Text style={styles.coinTicker}>Piyasa veri kaynağı</Text><Text style={styles.coinName}>Binance genel API · USDT pariteleri</Text></View>
        <View style={styles.livePill}><View style={styles.liveDot} /><Text style={styles.liveText}>AÇIK</Text></View>
      </View>
      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>Bu sürüm hakkında</Text>
        <Text style={styles.infoText}>Portföy ve takip listesi uygulama belleğinde tutulur; uygulama kapanınca kalıcı saklama henüz eklenmedi. Gerçek yayın öncesi kalıcı depolama, hata yönetimi, gizlilik metni ve testler eklenmelidir.</Text>
      </View>
    </ScrollView>
  );

  const renderTab = () => {
    switch (tab) {
      case 'Portföy': return <Portfolio />;
      case 'Takip': return <Watchlist />;
      case 'Grafikler': return <Charts />;
      case 'Uyarılar': return <AlertsScreen />;
      case 'Ayarlar': return <Settings />;
      default: return <Market />;
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <Header />
      <View style={{ flex: 1 }}>{renderTab()}</View>
      <View style={styles.bottomNav}>
        {[
          ['Piyasa', 'stats-chart-outline'], ['Portföy', 'wallet-outline'], ['Takip', 'star-outline'],
          ['Grafikler', 'analytics-outline'], ['Uyarılar', 'notifications-outline'], ['Ayarlar', 'settings-outline']
        ].map(([label, icon]) => (
          <TouchableOpacity key={label} onPress={() => setTab(label)} style={styles.navItem}>
            <Ionicons name={icon} size={20} color={tab === label ? C.green : C.muted} />
            <Text style={[styles.navLabel, { color: tab === label ? C.green : C.muted }]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

function SectionTitle({ title, right }) {
  return <View style={styles.sectionTitleRow}><Text style={styles.sectionTitle}>{title}</Text>{right ? <Text style={styles.sectionRight}>{right}</Text> : null}</View>;
}

const C = {
  bg: '#08111F', panel: '#101C2D', panel2: '#142236', border: '#203149',
  text: '#F1F5F9', muted: '#8A9BB1', green: '#36E0A1', red: '#FF6B7A',
  yellow: '#F5C451', blue: '#6AA9FF'
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { height: 70, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, borderBottomWidth: 1, borderBottomColor: C.border, gap: 11 },
  brandIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' },
  brand: { color: C.text, fontSize: 20, fontWeight: '900', letterSpacing: -0.6 },
  subBrand: { color: C.muted, fontSize: 9, letterSpacing: 1.5, marginTop: 2, fontWeight: '700' },
  iconBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: C.panel, alignItems: 'center', justifyContent: 'center' },
  content: { padding: 18, paddingBottom: 30 },
  greeting: { marginBottom: 18 },
  eyebrow: { color: C.green, fontSize: 10, fontWeight: '800', letterSpacing: 1.7, marginBottom: 8 },
  pageTitle: { color: C.text, fontSize: 25, fontWeight: '800', letterSpacing: -0.5 },
  muted: { color: C.muted, fontSize: 13, lineHeight: 20, marginTop: 5 },
  heroCard: { backgroundColor: '#122B35', borderRadius: 22, borderWidth: 1, borderColor: '#24544E', padding: 20, marginBottom: 24 },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  heroLabel: { color: '#A7C7C5', fontSize: 12 },
  heroValue: { color: C.text, fontSize: 30, fontWeight: '800', marginTop: 4 },
  heroUnit: { color: C.muted, fontSize: 13, fontWeight: '500' },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#1C433D', paddingHorizontal: 9, paddingVertical: 6, borderRadius: 20 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: C.green },
  liveText: { color: C.green, fontSize: 9, fontWeight: '900', letterSpacing: 0.6 },
  heroLine: { height: 1, backgroundColor: '#28514F', marginVertical: 18 },
  heroBottom: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  statLabel: { color: C.muted, fontSize: 11, marginBottom: 7 },
  heroPrice: { color: C.text, fontSize: 23, fontWeight: '800' },
  heroChange: { fontSize: 14, fontWeight: '800', marginBottom: 4 },
  sectionTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 6 },
  sectionTitle: { color: C.text, fontSize: 16, fontWeight: '800' },
  sectionRight: { color: C.muted, fontSize: 11 },
  panel: { backgroundColor: C.panel, borderRadius: 18, paddingHorizontal: 14, borderWidth: 1, borderColor: C.border, marginBottom: 22 },
  coinRow: { minHeight: 72, flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 10 },
  coinIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  coinInitial: { fontSize: 17, fontWeight: '900' },
  coinTicker: { color: C.text, fontSize: 13, fontWeight: '800' },
  coinName: { color: C.muted, fontSize: 11, marginTop: 4 },
  coinPrice: { color: C.text, fontSize: 12, fontWeight: '800' },
  coinChange: { fontSize: 11, fontWeight: '700', marginTop: 5 },
  starBtn: { padding: 6, marginLeft: 2 },
  rowDivider: { height: 1, backgroundColor: C.border },
  footnote: { color: '#71839A', fontSize: 10, lineHeight: 16, marginTop: -10, marginBottom: 18 },
  portfolioHero: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.border, borderRadius: 20, padding: 20, marginTop: 20, marginBottom: 12 },
  portfolioValue: { color: C.text, fontSize: 31, fontWeight: '900', marginBottom: 12 },
  pnlPill: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.panel2, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 8 },
  portfolioNote: { color: C.muted, fontSize: 10, marginTop: 13 },
  statsGrid: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  statCard: { flex: 1, backgroundColor: C.panel, borderRadius: 15, borderWidth: 1, borderColor: C.border, padding: 14 },
  statValue: { color: C.text, fontSize: 15, fontWeight: '800' },
  statDetail: { fontSize: 11, marginTop: 6, fontWeight: '700' },
  holdingRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: C.border },
  deleteBtn: { padding: 4 },
  emptyText: { color: C.muted, textAlign: 'center', padding: 25, fontSize: 12, lineHeight: 20 },
  formCard: { backgroundColor: C.panel, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: C.border, marginBottom: 24 },
  inputLabel: { color: C.muted, fontSize: 11, fontWeight: '700', marginBottom: 8, marginTop: 4 },
  input: { backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 12, color: C.text, paddingHorizontal: 13, paddingVertical: 12, marginBottom: 13, fontSize: 14 },
  chip: { paddingHorizontal: 15, paddingVertical: 9, borderRadius: 12, borderWidth: 1, borderColor: C.border, backgroundColor: C.panel, marginRight: 8 },
  chipActive: { backgroundColor: '#183E38', borderColor: C.green },
  chipText: { color: C.muted, fontSize: 12, fontWeight: '800' },
  chipTextActive: { color: C.green },
  primaryBtn: { backgroundColor: C.green, minHeight: 46, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, marginTop: 3 },
  primaryBtnText: { color: '#07111F', fontSize: 13, fontWeight: '900' },
  chartCard: { backgroundColor: C.panel, borderRadius: 20, borderWidth: 1, borderColor: C.border, padding: 18, marginBottom: 22 },
  chartPrice: { color: C.text, fontSize: 29, fontWeight: '900', marginTop: 9 },
  chartPlaceholder: { height: 225, marginTop: 22, borderRadius: 15, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', padding: 18 },
  chartPlaceholderTitle: { color: C.text, fontSize: 14, fontWeight: '800', marginTop: 10, marginBottom: 15 },
  chartRange: { color: C.muted, fontSize: 11, alignSelf: 'stretch', marginVertical: 5 },
  rangeLine: { width: '100%', height: 7, borderRadius: 5, backgroundColor: C.border, marginVertical: 7, overflow: 'hidden' },
  rangeFill: { height: 7, backgroundColor: C.green, borderRadius: 5 },
  signalCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.panel, borderRadius: 16, padding: 15, borderWidth: 1, borderColor: C.border, marginBottom: 18 },
  signalIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: '#1B2D49', alignItems: 'center', justifyContent: 'center' },
  alertRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.border },
  alertIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: C.panel2, alignItems: 'center', justifyContent: 'center' },
  currentPrice: { color: C.muted, fontSize: 11, marginBottom: 12 },
  settingCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.panel, borderWidth: 1, borderColor: C.border, borderRadius: 17, padding: 15, marginTop: 18 },
  settingIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: C.panel2, alignItems: 'center', justifyContent: 'center' },
  outlineBtn: { borderWidth: 1, borderColor: C.green, borderRadius: 10, paddingHorizontal: 13, paddingVertical: 8 },
  outlineBtnText: { color: C.green, fontSize: 11, fontWeight: '800' },
  infoCard: { backgroundColor: '#101F30', borderWidth: 1, borderColor: C.border, borderRadius: 16, padding: 16, marginTop: 15 },
  infoTitle: { color: C.text, fontSize: 13, fontWeight: '800', marginBottom: 10 },
  infoText: { color: C.muted, fontSize: 11, lineHeight: 18, marginBottom: 5 },
  bottomNav: { minHeight: 65, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', backgroundColor: '#0B1625', borderTopWidth: 1, borderTopColor: C.border, paddingHorizontal: 2, paddingBottom: 4 },
  navItem: { alignItems: 'center', justifyContent: 'center', flex: 1, paddingVertical: 7, gap: 4 },
  navLabel: { fontSize: 9, fontWeight: '700' }
});
